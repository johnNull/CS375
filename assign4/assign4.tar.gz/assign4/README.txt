To run:
make
./submission

did parts b1 and b2.
