To run:
make clean
make
./submission

Just hardcoded the adjacency matrix and used algorithms from slides. Should be working as expected.
