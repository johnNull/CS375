To run D&C:
make clean,
make
make run

To run Bruteforce:
make clean
make bruteforce
make run2

D&C method(assign2) was not finished. I just got the base cases down so it doesn't actually do anything, I couldn't figure it out in time. The bruteforce should be theta(n^2), The D&C method described in class would be nlog^2(n).
